import { useEffect, useState, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchTrendingVideos } from '../redux/videos/videoActions';
import type { RootState } from '../redux/rootReducer';
import Grids from '../Components/Grid';
import { Box,Typography,CircularProgress } from '@mui/material';
import CategoryList from '../Components/CategoryList';
import { fetchVideosByCategory } from '../api/youtubeApi';
import { setSelectedCategory } from '../redux/category/categoryActions';

const Homepage = () => {

    const dispatch = useDispatch<any>()
    // const [selectedCategoryId, setSelectedCategoryId] = useState<string|null>(null);
    // const [selectedCategory,setSelectedCategory] = useState('')
    const selectedCategoryId = useSelector((state: RootState) => state.category.selectedId);
const selectedCategory = useSelector((state: RootState) => state.category.selectedTitle);

    const [categoryVideos, setCategoryVideos] = useState([]);
    const [loadingCategoryVideos, setLoadingCategoryVideos] = useState(false);
    const [errorCategoryVideos, setErrorCategoryVideos] = useState(null);

    const store = useSelector((state: RootState) => state.videoState)

    useEffect(() => {
        if (store.trending.length === 0)
            dispatch(fetchTrendingVideos())
        console.log(store.trending)
    }, [store.trending.length]);


    useEffect(() => {
        let scrolled = false
        const threshold = 700
        const onScroll = () => {
            if (scrolled) return
            scrolled = true
            requestAnimationFrame(() => {
                try {

                    if (store.loading || !store.nextPageToken) return
                    const nearBottom = window.innerHeight + window.scrollY >= document.body.offsetHeight - threshold
                    if (nearBottom) {
                        dispatch(fetchTrendingVideos(store.nextPageToken))
                    }
                } finally {
                    scrolled = false
                }
            })
        }

        window.addEventListener('scroll', onScroll)
        return () => window.removeEventListener('scroll', onScroll)
    }, [store.nextPageToken, store.loading]);

    useEffect(() => {
        if (!selectedCategoryId) return

        const loadCategoryVideos = async () => {
            setLoadingCategoryVideos(true)
            setErrorCategoryVideos(null)
            try {
                const videos = await fetchVideosByCategory(selectedCategoryId, 'US')
                setCategoryVideos(videos)
            } catch (err: any) {
                setErrorCategoryVideos(err.message)
            } finally {
                setLoadingCategoryVideos(false)
            }

        }

        loadCategoryVideos();
    }, [selectedCategoryId])
    const displayTrending = !selectedCategoryId 


    const handleCategorySelect = useCallback((categoryId:string, category:string) => {
        dispatch(setSelectedCategory(categoryId || null, category || null));
    }, []);

    if (store.loading && store.trending.length === 0) {
        return <div className="loading">Loading videos...</div>;
    }

    if (store.error) {
        return <div className="error">Error fetching videos: {store.error}</div>;
    }

    return (
        <Box padding={2} justifyContent={'center'}>
            <Box sx={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'center',
                
            }}>
                <CategoryList
                    selectedCategoryId={selectedCategoryId}
                    onCategorySelect={handleCategorySelect} />
            </Box>
            {displayTrending ? (
                <>
                    <Typography variant='h5' gutterBottom>Trending Videos</Typography>
                    <Grids videos={store.trending} />
                    {store.loading && store.trending.length > 0 && (
                        <div style={{ textAlign: 'center', padding: 12 }}>Loading more...</div>
                    )}
                </>
            ) : (
                <>
                    <h1>{selectedCategory}</h1>
                    {loadingCategoryVideos ? (
                        <Box display="flex" justifyContent="center" padding={4}><CircularProgress /></Box>
                    ) : errorCategoryVideos ? (
                        <Typography color="error">{errorCategoryVideos}</Typography>
                    ) : (
                        <Grids videos={categoryVideos} />
                    )}
                </>
            )}
        </Box>
    );
};


export default Homepage;