// import React, { useEffect, useState } from "react";
// import { useParams, useNavigate } from "react-router-dom";
// import { Box, Typography, CircularProgress, Button, Divider } from "@mui/material";
// import moment from "moment";
// import { getVideoDetails, getRelatedVideos } from "../api/youtubeApi";
// import RelatedVideoItem from "../Components/RelatedVideoItem";
// import { ThumbUp, ThumbDown } from '@mui/icons-material';
// import { rateVideo } from "../api/youtubeApi";
// import { updateLocalUserLikes } from "../redux/auth/authThunk";

// import { useDispatch, useSelector } from "react-redux";
// import type { RootState } from "../redux/rootReducer";


// const WatchPage: React.FC = () => {
//   const { id } = useParams<{ id: string }>();
//   const dispatch = useDispatch();
//   const { user, token: accessToken, provider } = useSelector((state: RootState) => state.auth);

//   const initialRating = user?.likes?.[id] || 'none';
//   const [userRating, setUserRating] = useState(initialRating);
//   const [isLoadingAction, setIsLoadingAction] = useState(false);

//   useEffect(() => {
//     setUserRating(user?.likes?.[id] || 'none');
//   }, [user, id]);

//   const handleRating = async (rating) => {
//     setIsLoadingAction(true);

//     try {
//       if (provider === 'google' && accessToken) {
//         await rateVideo(accessToken, id, rating);

//         // if (rating === 'like' && userRating !== 'like') setPublicLikeCount(prev => prev + 1);
//         // if (rating === 'none' && userRating === 'like') setPublicLikeCount(prev => prev - 1);

//       } else if (provider === 'local' && user) {
//         dispatch(updateLocalUserLikes(id, rating));

//       } else {
//         alert("Please log in to rate videos.");
//         return;
//       }

//       setUserRating(rating);

//     } catch (error) {
//       console.error(error.message);
//       alert("Failed to update rating.");
//     } finally {
//       console.log(user.likes)
//       setIsLoadingAction(false);
//     }
//   };
//   const navigate = useNavigate();

//   const [video, setVideo] = useState<any | null>(null);
//   const [related, setRelated] = useState<any[]>([]);
//   const [loading, setLoading] = useState(false);
//   const [loadingRelated, setLoadingRelated] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   // const [likesMap, setLikesMap] = useState<Record<string, "like" | "dislike">>(readLikes());
//   // const [subs, setSubs] = useState<string[]>(readSubs());

//   useEffect(() => {

//     if (!id) return;
//     let canceled = false;
//     (async () => {
//       setLoading(true);
//       setError(null);
//       try {
//         const v = await getVideoDetails(id);
//         if (canceled) return;
//         setVideo(v);
//       } catch (err: any) {
//         if (canceled) return;
//         setError(err?.message ?? "Failed to load video");
//       } finally {
//         if (!canceled) setLoading(false);
//       }
//     })();

//     return () => {
//       canceled = true;
//     };
//   }, [id]);

//   useEffect(() => {
//     if (!id) return;
//     let canceled = false;
//     (async () => {
//       setLoadingRelated(true);
//       try {
//         const items = await getRelatedVideos(id, 12);
//         const filtered = items.filter((v: any) => v.id !== id);
//         if (canceled) return;
//         setRelated(filtered);
//       } catch (err) {
//         console.error("related error", err);
//       } finally {
//         if (!canceled) setLoadingRelated(false);
//       }
//     })();

//     return () => {
//       canceled = true;
//     };
//   }, [id]);


//   const openRelated = (videoId: string) => {

//     navigate(`/watch/${videoId}`);
//     window.scrollTo(0, 0);
//   };


//   const formatViews = (nStr: string | number | undefined) => {
//     const n = Number(nStr || 0);
//     if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M views";
//     if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K views";
//     return n + " views";
//   };
//   const formatLikes = (nStr: string | number | undefined) => {
//     const n = Number(nStr || 0);
//     if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
//     if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
//     return n + " views";
//   };

//   // const durationToLabel = (iso: string | undefined) => {

//   //   try {
//   //     if (!iso) return "";

//   //     const d = moment.duration(iso);
//   //     const hours = d.hours();
//   //     const minutes = d.minutes();
//   //     const seconds = d.seconds();
//   //     const hh = hours ? `${hours}:` : "";
//   //     const mm = hours ? String(minutes).padStart(2, "0") : String(minutes);
//   //     const ss = String(seconds).padStart(2, "0");
//   //     return hh + mm + ":" + ss;
//   //   } catch {
//   //     return "";
//   //   }
//   // };

//   if (!id) return <Box p={2}>No video selected</Box>;

//   if (loading) {
//     return (
//       <Box p={4} display="flex" justifyContent="center">
//         <CircularProgress />
//       </Box>
//     );
//   }

//   if (error) {
//     return (
//       <Box p={2}>
//         <Typography color="error">{error}</Typography>
//       </Box>
//     );
//   }

//   if (!video) {
//     return (
//       <Box p={2}>
//         <Typography>No video data</Typography>
//       </Box>
//     );
//   }

//   const snippet = video.snippet || {};
//   const stats = video.statistics || {};
//   const channelId = snippet.channelId;

//   return (
//     <Box
//       p={2}
//       display="grid"
//       gridTemplateColumns={{ xs: "1fr", md: "4fr 1fr" }}
//       gap={2}
//       alignItems="start"
//     >

//       <Box >
//         <Box sx={{ position: "relative", paddingTop: "56.25%", background: "#000", borderRadius: 1, overflow: "hidden" }}>
//           <iframe
//             title={snippet.title || "video player"}
//             src={`https://www.youtube.com/embed/${id}`}
//             style={{
//               position: "absolute",
//               top: 0,
//               left: 0,
//               width: "100%",
//               height: "100%",
//               border: 0,
//             }}
//             allowFullScreen
//           />
//         </Box>

//         <Typography variant="h6" mt={2} sx={{ fontWeight: 700 }}>
//           {snippet.title}
//         </Typography>

//         <Box display="flex" gap={2} alignItems="center" mt={1}>
//           <Box>
//             <Typography variant="subtitle2">{snippet.channelTitle}</Typography>
//             <Typography variant="body2" color="text.secondary">
//               {formatViews(stats.viewCount)} • {moment(snippet.publishedAt).fromNow()}
//             </Typography>
//           </Box>

//           <Box marginLeft="auto" display="flex" gap={1}>
//             <Box display={"flex"} flexDirection={"column"} justifyContent={"center"} alignItems={"center"}>
//               <Button
//                 sx={{
//                   color: userRating === 'like' ? 'black' : 'grey'
//                 }}
//                 onClick={() => handleRating(userRating === 'like' ? 'none' : 'like')}
//                 disabled={isLoadingAction}
//                 startIcon={<ThumbUp
//                 />}
//                 variant="text"
//               >
//                 <Typography variant="subtitle2"  >
//                   {formatLikes(stats.likeCount)}
//                 </Typography>
//               </Button>


//             </Box>
//             <Button
//               sx={{
//                 color: userRating === 'dislike' ? 'black' : 'grey'
//               }}
//               onClick={() => handleRating(userRating === 'dislike' ? 'none' : 'dislike')}
//               disabled={isLoadingAction}
//               startIcon={<ThumbDown />}
//               variant="text"

//             >

//             </Button>
//             <Button
//               color="primary"
//               variant={"contained"}
//             // onClick={() => toggleSubscribe(channelId)}
//             >
//               {/* {isSubscribed(channelId) ? "Subscribed" : "Subscribe"} */}
//             </Button>
//           </Box>
//         </Box>

//         <Divider sx={{ my: 2 }} />

//         <Typography variant="body2" sx={{ whiteSpace: "pre-line" }}>
//           {snippet.description}
//         </Typography>
//       </Box>


//       <Box>
//         <Typography variant="subtitle1" mb={1}>
//           Related
//         </Typography>

//         {loadingRelated && <CircularProgress size={20} />}

//         {!loadingRelated && related.length === 0 && <Typography>No related videos found</Typography>}

//         {!loadingRelated && related.length > 0 && (
//           <Box
//             sx={{
//               maxHeight: "calc(100vh - 180px)",
//               overflowY: "auto",
//               pr: 1,
//             }}
//           >
//             {related.map((video, index) => (
//               <RelatedVideoItem key={index} video={video} onClick={openRelated} />
//             ))}
//           </Box>
//         )}
//       </Box>
//     </Box>
//   );

// };

// export default WatchPage;


// src/Pages/WatchPage.tsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Box, Typography, CircularProgress, Button, Divider } from "@mui/material";
import moment from "moment";
import { getVideoDetails, getRelatedVideos, rateVideo, checkSubscriptionStatus, subscribeToChannel, unsubscribe } from "../api/youtubeApi";
import RelatedVideoItem from "../Components/RelatedVideoItem";
import { ThumbUp, ThumbDown } from '@mui/icons-material';
import { updateLocalUserLikes, toggleLocalSubscription } from "../redux/auth/authThunk";

import { useDispatch, useSelector } from "react-redux";
import type { RootState } from "../redux/rootReducer";


const WatchPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch();
  const { user, token: accessToken, provider } = useSelector((state: RootState) => state.auth);

  const initialRating = user?.likes?.[id] || 'none';
  const [userRating, setUserRating] = useState(initialRating);
  const [isLoadingAction, setIsLoadingAction] = useState(false);

  const [video, setVideo] = useState<any | null>(null);
  const [related, setRelated] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingRelated, setLoadingRelated] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [isSubscribedState, setIsSubscribedState] = useState<boolean>(false);
  const [subscriptionIdState, setSubscriptionIdState] = useState<string | null>(null);
  const [subLoading, setSubLoading] = useState(false);

  useEffect(() => {
    setUserRating(user?.likes?.[id] || 'none');
  }, [user, id]);

  useEffect(() => {
    if (!id) return;
    let canceled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const v = await getVideoDetails(id);
        if (canceled) return;
        setVideo(v);
      } catch (err: any) {
        if (canceled) return;
        setError(err?.message ?? "Failed to load video");
      } finally {
        if (!canceled) setLoading(false);
      }
    })();

    return () => {
      canceled = true;
    };
  }, [id]);

  useEffect(() => {
    if (!id) return;
    let canceled = false;
    (async () => {
      setLoadingRelated(true);
      try {
        const items = await getRelatedVideos(id, 12);
        const filtered = items.filter((v: any) => v.id !== id);
        if (canceled) return;
        setRelated(filtered);
      } catch (err) {
        console.error("related error", err);
      } finally {
        if (!canceled) setLoadingRelated(false);
      }
    })();

    return () => {
      canceled = true;
    };
  }, [id]);

  // Initialize subscription status when video (and therefore channelId) is available or when auth changes
  useEffect(() => {
    let canceled = false;
    async function initSubscription() {
      const snippet = video?.snippet || {};
      const channelId = snippet.channelId;
      if (!channelId) return;

      if (provider === "google" && accessToken) {
        try {
          const res = await checkSubscriptionStatus(accessToken as string, channelId);
          if (canceled) return;
          if (Array.isArray(res.items) && res.items.length) {
            setIsSubscribedState(true);
            setSubscriptionIdState(res.items[0].id || null);
          } else {
            setIsSubscribedState(false);
            setSubscriptionIdState(null);
          }
        } catch (err) {
          console.error("checkSubscriptionStatus failed", err);
          if (!canceled) {
            setIsSubscribedState(false);
            setSubscriptionIdState(null);
          }
        }
      } else if (provider === "local" && user) {
        try {
    const stored = localStorage.getItem("youstream_local_user:" + user.email);
    if (stored) {
      const persisted = JSON.parse(stored);
      const subs: string[] = Array.isArray(persisted.subs) ? persisted.subs : [];
      setIsSubscribedState(subs.includes(channelId));
      setSubscriptionIdState(null);
    } else {
      // fallback to redux user in-memory
      const subs: string[] = Array.isArray(user.subs) ? user.subs : [];
      setIsSubscribedState(subs.includes(channelId));
      setSubscriptionIdState(null);
    }
  } catch (e) {
    const subs: string[] = Array.isArray(user.subs) ? user.subs : [];
    setIsSubscribedState(subs.includes(channelId));
    setSubscriptionIdState(null);
  }

      } else {
        setIsSubscribedState(false);
        setSubscriptionIdState(null);
      }
    }

    initSubscription();
    return () => { canceled = true; };
  }, [video, provider, accessToken, user]);

  const handleRating = async (rating) => {
    setIsLoadingAction(true);

    try {
      if (provider === 'google' && accessToken) {
        await rateVideo(accessToken, id, rating);
      } else if (provider === 'local' && user) {
        await dispatch(updateLocalUserLikes(id, rating) as any);
      } else {
        alert("Please log in to rate videos.");
        return;
      }

      setUserRating(rating);

    } catch (error: any) {
      console.error(error?.message ?? error);
      alert("Failed to update rating.");
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handleSubscribeToggle = async () => {
    setSubLoading(true);
    try {
      const snippet = video?.snippet || {};
      const channelId = snippet.channelId;
      if (!channelId) {
        alert("Channel information not available yet.");
        return;
      }

      if (provider === "google" && accessToken) {
        if (!isSubscribedState) {
          // subscribe
          const res = await subscribeToChannel(accessToken as string, channelId);
          const newId = res?.id ?? null;
          setIsSubscribedState(true);
          setSubscriptionIdState(newId);
          // optionally persist subscriptionId in localStorage if you want to survive refresh:
          try {
            localStorage.setItem(`yst_sub_${channelId}`, JSON.stringify({ subscriptionId: newId }));
          } catch {}
        } else {
          // unsubscribe
          if (subscriptionIdState) {
            await unsubscribe(accessToken as string, subscriptionIdState);
            setIsSubscribedState(false);
            setSubscriptionIdState(null);
            try {
              localStorage.removeItem(`yst_sub_${channelId}`);
            } catch {}
          } else {
            // fallback: try to find the subscription and delete
            try {
              const s = await checkSubscriptionStatus(accessToken as string, channelId);
              if (Array.isArray(s.items) && s.items.length) {
                const sid = s.items[0].id;
                await unsubscribe(accessToken as string, sid);
              }
            } catch (e) { /* ignore */ }
            setIsSubscribedState(false);
            setSubscriptionIdState(null);
            try {
              localStorage.removeItem(`yst_sub_${channelId}`);
            } catch {}
          }
        }
      } else if (provider === "local" && user) {
        await dispatch(toggleLocalSubscription(channelId) as any);
  // read persisted user to get authoritative subs
  try {
    const stored = localStorage.getItem("youstream_local_user:" + user.email);
    if (stored) {
      const persisted = JSON.parse(stored);
      const subs: string[] = Array.isArray(persisted.subs) ? persisted.subs : [];
      setIsSubscribedState(subs.includes(channelId));
    } else {
      setIsSubscribedState(prev => !prev);
    }
  } catch {
    setIsSubscribedState(prev => !prev);
  }
      } else {
        alert("Please sign in (local or Google) to subscribe.");
      }
    } catch (err) {
      console.error("Subscribe toggle failed", err);
      alert("Failed to change subscription. Try again.");
    } finally {
      setSubLoading(false);
    }
  };

  const navigate = useNavigate();

  const openRelated = (videoId: string) => {
    navigate(`/watch/${videoId}`);
    window.scrollTo(0, 0);
  };

  const formatViews = (nStr: string | number | undefined) => {
    const n = Number(nStr || 0);
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M views";
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K views";
    return n + " views";
  };
  const formatLikes = (nStr: string | number | undefined) => {
    const n = Number(nStr || 0);
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n + " views";
  };

  if (!id) return <Box p={2}>No video selected</Box>;

  if (loading) {
    return (
      <Box p={4} display="flex" justifyContent="center">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box p={2}>
        <Typography color="error">{error}</Typography>
      </Box>
    );
  }

  if (!video) {
    return (
      <Box p={2}>
        <Typography>No video data</Typography>
      </Box>
    );
  }

  const snippet = video.snippet || {};
  const stats = video.statistics || {};
  const channelId = snippet.channelId;

  return (
    <Box
      p={2}
      display="grid"
      gridTemplateColumns={{ xs: "1fr", md: "4fr 1fr" }}
      gap={2}
      alignItems="start"
    >

      <Box >
        <Box sx={{ position: "relative", paddingTop: "56.25%", background: "#000", borderRadius: 1, overflow: "hidden" }}>
          <iframe
            title={snippet.title || "video player"}
            src={`https://www.youtube.com/embed/${id}`}
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              border: 0,
            }}
            allowFullScreen
          />
        </Box>

        <Typography variant="h6" mt={2} sx={{ fontWeight: 700 }}>
          {snippet.title}
        </Typography>

        <Box display="flex" gap={2} alignItems="center" mt={1}>
          <Box>
            <Typography variant="subtitle2">{snippet.channelTitle}</Typography>
            <Typography variant="body2" color="text.secondary">
              {formatViews(stats.viewCount)} • {moment(snippet.publishedAt).fromNow()}
            </Typography>
          </Box>

          <Box marginLeft="auto" display="flex" gap={1}>
            <Box display={"flex"} flexDirection={"column"} justifyContent={"center"} alignItems={"center"}>
              <Button
                sx={{
                  color: userRating === 'like' ? 'black' : 'grey'
                }}
                onClick={() => handleRating(userRating === 'like' ? 'none' : 'like')}
                disabled={isLoadingAction}
                startIcon={<ThumbUp />}
                variant="text"
              >
                <Typography variant="subtitle2"  >
                  {formatLikes(stats.likeCount)}
                </Typography>
              </Button>


            </Box>
            <Button
              sx={{
                color: userRating === 'dislike' ? 'black' : 'grey'
              }}
              onClick={() => handleRating(userRating === 'dislike' ? 'none' : 'dislike')}
              disabled={isLoadingAction}
              startIcon={<ThumbDown />}
              variant="text"

            >

            </Button>
            <Button
              color="primary"
              variant={isSubscribedState ? "contained" : "outlined"}
              onClick={handleSubscribeToggle}
              disabled={subLoading}
            >
              {isSubscribedState ? "Subscribed" : "Subscribe"}
            </Button>
          </Box>
        </Box>

        <Divider sx={{ my: 2 }} />

        <Typography variant="body2" sx={{ whiteSpace: "pre-line" }}>
          {snippet.description}
        </Typography>
      </Box>


      <Box>
        <Typography variant="subtitle1" mb={1}>
          Related
        </Typography>

        {loadingRelated && <CircularProgress size={20} />}

        {!loadingRelated && related.length === 0 && <Typography>No related videos found</Typography>}

        {!loadingRelated && related.length > 0 && (
          <Box
            sx={{
              maxHeight: "calc(100vh - 180px)",
              overflowY: "auto",
              pr: 1,
            }}
          >
            {related.map((video, index) => (
              <RelatedVideoItem key={index} video={video} onClick={openRelated} />
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );

};

export default WatchPage;
