// import React, { useState, useEffect } from "react";
// import {
//   Box,
//   Paper,
//   Typography,
//   TextField,
//   Button,
// } from "@mui/material";
// import { useDispatch } from "react-redux";
// import { Link, useNavigate } from "react-router-dom";
// import { signupLocal, loginGoogle } from "../redux/auth/authThunk";
// import { GoogleLogin } from "@react-oauth/google";
// import { jwtDecode } from 'jwt-decode'

// export default function SignupPage() {
//   const dispatch = useDispatch<any>();
//   const nav = useNavigate();

//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [pass, setPass] = useState("");
//   const [confirm, setConfirm] = useState("");
//   const [err, setErr] = useState<string | null>(null);
//   const [loading, setLoading] = useState(false);


//   const handleGoogleSuccess = async (res) => {
//     const token = res.credential;
//     const decoded = jwtDecode(token)
//     try {
//       setLoading(true);
//       const res = await dispatch(loginGoogle(decoded.email, token));
//       setLoading(false);
//       if (res) {
//         setErr(res || "Login failed");
//       }
//       else
//         nav("/");
//     } catch (error: any) {
//       setLoading(false);
//       setErr(error?.message || "Login failed");
//     }

//   }
//   const submit = async (e?: React.FormEvent) => {
//     if (e) e.preventDefault();
//     setErr(null);
//     if (!email.trim()) return setErr("Please enter email");
//     if (!pass.trim()) return setErr("Please enter password");
//     if (pass !== confirm) return setErr("Passwords do not match");

//     try {
//       setLoading(true);
//       await dispatch(signupLocal(email.trim(), pass));
//       const key = "youstream_local_user:" + email.trim();
//       const user = localStorage.getItem(key);
//       if (user) {
//         try {
//           const u = JSON.parse(user);
//           u.name = name || u.name || email.split("@")[0];
//           localStorage.setItem(key, JSON.stringify(u));
//           await dispatch(signupLocal(email.trim(), pass));
//         } catch { }
//       }
//       setLoading(false);
//       nav("/");
//     } catch (e: any) {
//       setLoading(false);
//       setErr(e?.message || "Signup failed");
//     }
//   };

//   return (
//     <Box
//       sx={{
//         minHeight: "80vh",
//         display: "flex",
//         justifyContent: "center",
//         alignItems: "center",
//         background: "#fafafa",
//         p: 2,
//       }}
//     >
//       <Paper sx={{ width: 460, maxWidth: "95%", p: 4 }} elevation={3}>
//         <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
//           Create an account
//         </Typography>
//         <Typography variant="body2" color="text.secondary" mb={3}>
//           Join YouStream — sign up with email or use Google to continue.
//         </Typography>

//         <form onSubmit={submit} >
//           <TextField
//             label="Name (optional)"
//             size="small"
//             fullWidth
//             margin="normal"
//             value={name}
//             onChange={(e) => setName(e.target.value)}
//           />
//           <TextField
//             label="Email"
//             size="small"
//             fullWidth
//             margin="normal"
//             value={email}
//             onChange={(e) => setEmail(e.target.value)}
//           />
//           <TextField
//             label="Password"
//             size="small"
//             fullWidth
//             margin="normal"
//             type="password"
//             value={pass}
//             onChange={(e) => setPass(e.target.value)}
//           />
//           <TextField
//             label="Confirm password"
//             size="small"
//             fullWidth
//             margin="normal"
//             type="password"
//             value={confirm}
//             onChange={(e) => setConfirm(e.target.value)}
//           />

//           {err && (
//             <Typography color="error" fontSize={13} mt={1}>
//               {err}
//             </Typography>
//           )}

//           <Button
//             type="submit"
//             variant="contained"
//             fullWidth
//             sx={{ mt: 2, py: 1.6, borderRadius: 6 }}
//             disabled={loading}
//           >
//             {loading ? "Creating..." : "Create account"}
//           </Button>
//         </form>

//         <Box textAlign="center" mt={3} mb={1} color="text.secondary">
//           <Typography variant="body2">or continue with</Typography>
//         </Box>

     
//         <GoogleLogin onSuccess={handleGoogleSuccess}
//           shape="rectangular"
//           type="standard"
//           size="large"
//           theme="outline" />

//         <Box mt={2} display="flex" justifyContent="center" gap={1}
//           sx={{
//             display: "flex",
//             flexDirection: "row",
//             justifyContent: "center",
//             alignItems: "center"
//           }}>
//           <Typography variant="body2">Already have an account?</Typography>
//           <Button component={Link} to="/login" variant="text" size="small">
//             Sign in
//           </Button>
//         </Box>
//       </Paper>
//     </Box>
//   );
// }
// src/Pages/SignupPage.tsx
import React, { useState } from "react";
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
} from "@mui/material";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { signupLocal, loginGoogle } from "../redux/auth/authThunk";
import { GoogleLogin } from "@react-oauth/google";
import { jwtDecode } from "jwt-decode";

export default function SignupPage() {
  const dispatch = useDispatch<any>();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErr(null);
    if (!email.trim()) return setErr("Please enter email");
    if (!pass.trim()) return setErr("Please enter password");
    if (pass !== confirm) return setErr("Passwords do not match");

    try {
      setLoading(true);
      await dispatch(signupLocal(email.trim(), pass));
      const key = "youstream_local_user:" + email.trim();
      const user = localStorage.getItem(key);
      if (user) {
        try {
          const u = JSON.parse(user);
          u.name = name || u.name || email.split("@")[0];
          localStorage.setItem(key, JSON.stringify(u));
          await dispatch(signupLocal(email.trim(), pass));
        } catch {}
      }
      setLoading(false);
      navigate("/");
    } catch (e: any) {
      setLoading(false);
      setErr(e?.message || "Signup failed");
    }
  };

  const handleGoogleSuccess = async (response: any) => {
    const idToken = response?.credential;
    if (!idToken) {
      setErr("Google sign-in failed (no credential).");
      return;
    }
    let decoded: any;
    try {
      decoded = jwtDecode(idToken);
    } catch (err) {
      console.error("Failed to decode ID token", err);
      setErr("Google sign-in failed (decode error).");
      return;
    }

    const profileEmail = decoded?.email;
    const profileName = decoded?.name;
    if (!profileEmail) {
      setErr("Could not decode email from Google response.");
      return;
    }

    const win: any = window;
    if (!win?.google?.accounts?.oauth2) {
      setErr("Google Identity library not loaded.");
      return;
    }

    const tokenClient = win.google.accounts.oauth2.initTokenClient({
      client_id: import.meta.env.VITE_GOOGLE_OAUTH_CLIENT_ID,
      scope: "https://www.googleapis.com/auth/youtube.force-ssl",
      callback: (tokenResp: any) => {
        const accessToken = tokenResp?.access_token;
        if (!accessToken) {
          setErr("Failed to obtain access token from Google.");
          return;
        }
        dispatch(
          loginGoogle({
            email: profileEmail,
            name: profileName,
            idToken,
            accessToken,
          })
        );
        navigate("/");
      },
    });

    // Requesting access token immediately (behaves like LoginPage)
    tokenClient.requestAccessToken();
  };

  const handleGoogleError = () => {
    setErr("Google sign-in was unsuccessful.");
  };

  return (
    <Box
      sx={{
        minHeight: "80vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#fafafa",
        p: 2,
      }}
    >
      <Paper sx={{ width: 460, maxWidth: "95%", p: 4 }} elevation={3}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
          Create an account
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Join YouStream — sign up with email or use Google to continue.
        </Typography>

        <form onSubmit={submit}>
          <TextField
            label="Name (optional)"
            size="small"
            fullWidth
            margin="normal"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            label="Email"
            size="small"
            fullWidth
            margin="normal"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <TextField
            label="Password"
            size="small"
            fullWidth
            margin="normal"
            type="password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
          />
          <TextField
            label="Confirm password"
            size="small"
            fullWidth
            margin="normal"
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />

          {err && (
            <Typography color="error" fontSize={13} mt={1}>
              {err}
            </Typography>
          )}

          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{ mt: 2, py: 1.6, borderRadius: 6 }}
            disabled={loading}
          >
            {loading ? "Creating..." : "Create account"}
          </Button>
        </form>

        <Box textAlign="center" mt={3} mb={1} color="text.secondary">
          <Typography variant="body2">or continue with</Typography>
        </Box>

        <Box display="flex" justifyContent="center" mb={2}>
          <GoogleLogin onSuccess={handleGoogleSuccess} onError={handleGoogleError} shape="rectangular" type="standard" size="large" theme="outline" />
        </Box>

        <Box mt={2} display="flex" justifyContent="center" gap={1} sx={{ display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center" }}>
          <Typography variant="body2">Already have an account?</Typography>
          <Button component={Link} to="/login" variant="text" size="small">
            Sign in
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
